// وكيل التحديث التكيفي من جانب العميل
let localState = {
    version: 0,
    header: { title: "", subtitle: "", images: [] },
    ticker: [],
    design: {},
    categories: [],
    stores: {},
    products: {},
    testimonials: [],
    footer: { email: "", phone: "", whatsapp: "", social: [], payments: [] }
};

// العناصر المطلوب تحديثها
const elements = {
    headerTitle: document.getElementById('headerTitle'),
    headerSubtitle: document.getElementById('headerSubtitle'),
    tickerContent: document.getElementById('tickerContent'),
    categoriesContainer: document.getElementById('categoriesContainer'),
    testimonialsTrack: document.getElementById('testimonialsTrack'),
    footerSection: document.getElementById('footerSection'),
    whatsappFloat: document.getElementById('whatsappFloat')
};

async function fetchState() {
    try {
        const response = await fetch('/api/site-state');
        if (!response.ok) throw new Error('فشل الجلب');
        return await response.json();
    } catch (error) {
        console.error('خطأ في جلب الحالة:', error);
        return null;
    }
}

function applyDesign(design) {
    const root = document.documentElement;
    if (design.categoryBg) root.style.setProperty('--category-bg', design.categoryBg);
    if (design.categoryText) root.style.setProperty('--category-text', design.categoryText);
    if (design.categoryFontSize) root.style.setProperty('--category-font-size', design.categoryFontSize);
    if (design.storeBg) root.style.setProperty('--store-bg', design.storeBg);
    if (design.storeText) root.style.setProperty('--store-text', design.storeText);
    if (design.storeFontSize) root.style.setProperty('--store-font-size', design.storeFontSize);
    if (design.productBg) root.style.setProperty('--product-bg', design.productBg);
    if (design.productText) root.style.setProperty('--product-text', design.productText);
    if (design.productFontSize) root.style.setProperty('--product-font-size', design.productFontSize);
    if (design.adBg) root.style.setProperty('--ad-bg', design.adBg);
    if (design.adText) root.style.setProperty('--ad-text', design.adText);
    if (design.adFontSize) root.style.setProperty('--ad-font-size', design.adFontSize);
    if (design.generalFontSize) {
        root.style.setProperty('--general-font-size', design.generalFontSize);
        document.body.style.fontSize = design.generalFontSize;
    }
}

function updateHeader(header) {
    if (elements.headerTitle && header.title !== localState.header.title)
        elements.headerTitle.textContent = header.title;
    if (elements.headerSubtitle && header.subtitle !== localState.header.subtitle)
        elements.headerSubtitle.textContent = header.subtitle;
    // يمكن إضافة تغيير خلفية الهيدر هنا
}

function updateTicker(ticker) {
    if (elements.tickerContent && JSON.stringify(ticker) !== JSON.stringify(localState.ticker)) {
        elements.tickerContent.innerHTML = ticker.map(t => `<span>${t}</span>`).join('');
    }
}

function updateCategories(categories, stores, products) {
    if (!elements.categoriesContainer) return;
    // إذا تغيرت البيانات بشكل كبير، نعيد تحميل الصفحة أو نحدثها جزئياً
    if (JSON.stringify(categories) !== JSON.stringify(localState.categories) ||
        JSON.stringify(stores) !== JSON.stringify(localState.stores) ||
        JSON.stringify(products) !== JSON.stringify(localState.products)) {
        // يمكن استدعاء دالة renderHomePage هنا (يفضل إعادة هيكلتها لتكون قابلة للاستدعاء)
        console.log('تغير في بيانات الفئات/المتاجر/المنتجات، يرجى إعادة تحميل الصفحة لرؤية التحديثات');
        // يمكنك إظهار رسالة للمستخدم
    }
}

function updateTestimonials(testimonials) {
    if (!elements.testimonialsTrack) return;
    if (JSON.stringify(testimonials) === JSON.stringify(localState.testimonials)) return;
    let html = '';
    testimonials.forEach(t => {
        let stars = '';
        for (let i = 0; i < 5; i++) stars += i < t.rating ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
        html += `<div class="testimonial-card"><img src="${t.image}" class="customer-img"><div class="customer-name">${t.name}</div><div class="customer-rating">${stars}</div><div class="customer-review">${t.review}</div></div>`;
    });
    elements.testimonialsTrack.innerHTML = html;
}

function updateFooter(footer) {
    if (!elements.footerSection) return;
    if (JSON.stringify(footer) === JSON.stringify(localState.footer)) return;
    elements.footerSection.innerHTML = `
        <div class="contact-section">
            <h3>تواصل معنا</h3>
            <p>البريد الإلكتروني: ${footer.email || ''}</p>
            <p>الهاتف: ${footer.phone || ''}</p>
            <div class="social-icons">${(footer.social || []).map(s => `<a href="${s.url}"><i class="${s.icon}"></i></a>`).join('')}</div>
        </div>
        <div class="payment-section">
            <h3>خدمات الدفع</h3>
            <p>طرق دفع آمنة ومتعددة</p>
            <div class="payment-methods">${(footer.payments || []).map(p => `<i class="${p}"></i>`).join('')}</div>
        </div>
    `;
    if (elements.whatsappFloat) {
        elements.whatsappFloat.href = footer.whatsapp || 'https://wa.me/96777856209';
    }
}

function updateUI(newState) {
    if (!newState) return;
    applyDesign(newState.design);
    updateHeader(newState.header);
    updateTicker(newState.ticker);
    updateCategories(newState.categories, newState.stores, newState.products);
    updateTestimonials(newState.testimonials);
    updateFooter(newState.footer);
    localState = newState;
}

async function checkForUpdates() {
    const serverState = await fetchState();
    if (serverState && serverState.version !== localState.version) {
        console.log('تم اكتشاف تحديث جديد، جاري التحديث...');
        updateUI(serverState);
    }
}

(async function init() {
    const initialState = await fetchState();
    if (initialState) {
        localState = initialState;
        updateUI(initialState);
    } else {
        console.error('فشل تحميل الحالة الأولية');
    }
    setInterval(checkForUpdates, 30000); // كل 30 ثانية
})();